<template>
  <div class="wrapper">
  <div class="catalog-body">
    <div class="catalog__items">
      <CatalogItem v-for="(item, index) in catalog_items"  :catalogproduct_data="item" @addToCart="addToCart(index)" />
    </div>
  </div>
  </div>
</template>

<script>
  import CartPage from './CartPage.vue'
  import './assets/styles/style.scss'
  import CartItem from './components/Cart'
  import Button from './components/Button'
  import cartTitles from './components/cartTitles'
  import cartHeader from './components/cartHeader'
  import textInputs from './components/textInputs'
  import selects from './components/selects'
  import CatalogItem from './components/CatalogItem'
  import totalItem from './components/totalItem'
  import { mapGetters } from 'vuex';

  export default {
    name: 'catalog',
    data() {
      return {

      }
    },
    methods: {
      addToCart(index) {
        this.$store.dispatch('ADD_TO_CART', index);
      }
    },
    computed: {
      ...mapGetters({
        catalog_items: 'CATALOG_PRODUCTS'
      })
    },
    components: {
      CartPage,
      CartItem,
      Button,
      cartTitles,
      cartHeader,
      textInputs,
      selects,
      totalItem,
      CatalogItem
    }
  }
</script>

<style scoped>
.catalog__items {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
  align-items: baseline;
}
</style>
