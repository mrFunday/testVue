import Vue from 'vue'
import catalog from './catalog.vue'
import Vuex from 'vuex'
// import VueRouter from 'vue-router'
//
// Vue.use(VueRouter);

Vue.use(Vuex);
const store = new Vuex.Store({
  state: {
    catalogProducts: [
      { img: 'src/assets/img/Symbol 20 – 1.png',
        title: 'Pants',
        priceNew: '900',
        article: 'SL-123RS',
        size: '36',
        color: 'Синий',
        qty: 1,
      },
      { img: 'src/assets/img/Symbol 20 – 1.png',
        title: 'Shirt',
        priceNew: '500',
        article: 'SL-113RS',
        size: '33',
        color: 'Красный',
        qty: 1,
      },
      { img: 'src/assets/img/Symbol 20 – 1.png',
        title: 'Boots',
        priceNew: '1200',
        article: 'SL-153RS',
        size: '37',
        color: 'Белый',
        qty: 1,
      }
    ],
    products: [
      {
        img: 'src/assets/img/Symbol 20 – 1.png',
        title: 'Джинсы',
        id: 'jeans',
        article: 'SL-123RS',
        size: '36',
        color: 'Синий',
        priceOld: '1000',
        priceNew: 1000,
        promocode: 'ПРОМОКОД',
        akciyaName: '-20% на вторые низы',
        akciyaPerc: 20,
        akciyaPrice: '',
        pricePromo: 100,
        totalPrice: 0,
        qty: 1,
        amount: 0,
        delivery: true
      },
      {
        img: 'src/assets/img/Symbol 20 – 1.png',
        title: 'Майка',
        id: 'shirt',
        article: 'SL-GFD65',
        size: '48',
        color: 'Красный',
        priceOld: '2000',
        priceNew: 1500,
        promocode: 'ПРОМОКОД',
        akciyaName: '-30% на вторые низы',
        akciyaPerc: 30,
        akciyaPrice: '',
        pricePromo: 200,
        totalPrice: 0,
        qty: 1,
        amount: 2,
        delivery: false
      },
      {
        img: 'src/assets/img/Symbol 20 – 1.png',
        title: 'Шорты',
        id: 'shorts',
        article: 'DF-GHK31',
        size: '32',
        color: 'Белый',
        priceOld: '2500',
        priceNew: 1700,
        promocode: 'ПРОМОКОД',
        akciyaName: '-50% на вторые низы',
        akciyaPerc: 50,
        akciyaPrice: '',
        pricePromo: 300,
        totalPrice: 0,
        qty: 1,
        amount: 3,
        delivery: true
      }
    ],
    cities: [
      'Город *',
      'Moscow',
      'Sp',
      'London'
    ],
    metro: [
      'Станция метро *',
      'station1',
      'station2',
      'station3'
    ],
    time: [
      '12:00',
      '13:00',
      '14:00',
      '15:00',
      '16:00'
    ],
    superTotalCost: 0,
    superPricePromo: 0,
    superAkciyaPrice: 0,
    superPriceNew: 0,
    superBonus: 250
  },
  getters: {
    PRODUCTS: state => {
      return state.products;
    },
    CATALOG_PRODUCTS: state => {
      return state.catalogProducts;
    }
  },
  mutations: {
    REMOVE: (state, payload) => {
      state.products.splice(payload, 1);
    },
    ADD_CART: ( state, payload ) => {
      state.products.push({
        img: state.catalogProducts[payload].img,
        title: state.catalogProducts[payload].title,
        priceNew: state.catalogProducts[payload].priceNew,
        article: state.catalogProducts[payload].article,
        size: state.catalogProducts[payload].size,
        color: state.catalogProducts[payload].color,
        qty: state.catalogProducts[payload].qty
      });
      console.log(state.products);
    },
    PLUS: (state, payload) => {
      if ( state.products[payload].qty < 1 ) {
        state.products[payload].qty++;
        state.products[payload].totalPrice += state.products[payload].priceNew - ( state.products[payload].pricePromo + state.products[payload].akciyaPrice );
      }
      else {
        state.products[payload].qty++;
        state.products[payload].totalPrice += state.products[payload].priceNew;
      }
    },
    MINUS: (state, payload) => {
      state.products[payload].qty--;
      state.products[payload].totalPrice -= state.products[payload].priceNew;
      if ( state.products[payload].totalPrice < 0 ) {
        state.products[payload].totalPrice = 0
      }
    },
    SET_TOTAL_PRICE: (state) => {
      for (var i = 0; i < state.products.length; i++) {
          var perc = state.products[i].akciyaPerc;
          var total = state.products[i].priceNew;
          state.products[i].akciyaPrice = (perc * total) / 100;
          state.products[i].totalPrice = state.products[i].priceNew - state.products[i].pricePromo - state.products[i].akciyaPrice;
      }
    },
    TOTAL_COST: (state) => {
      var summTotal = 0;
      var summPromo = 0;
      var summAkciya = 0;
      var summPriceNew = 0;
      var summBonus = 250;


      for (var i = 0; i < state.products.length; i++) {
        if (state.products[i].qty > 0) {
          summTotal += parseInt(state.products[i].totalPrice);
          summPromo += parseInt(state.products[i].pricePromo);
          summAkciya += parseInt(state.products[i].akciyaPrice);
          summPriceNew += parseInt(state.products[i].priceNew * state.products[i].qty);
        }

        state.superTotalCost = summTotal - summBonus;
        state.superPricePromo = summPromo;
        state.superAkciyaPrice = summAkciya;
        state.superPriceNew = summPriceNew;
        state.superBonus = summBonus;
      }
      if ( state.superTotalCost < 0 ) {
        state.superTotalCost = 0
      }
    }

  },
  actions: {
    ADD_TO_CART: ( context, payload ) => {
      context.commit( 'ADD_CART', payload );
    },
    REMOVE_ITEMS: ( context, payload ) => {
      context.commit('REMOVE', payload);
    },
    PLUS_QTY: ( context, payload ) => {
      context.commit( 'PLUS', payload );
    },
    MINUS_QTY: ( context, payload ) => {
      context.commit ('MINUS', payload);
    },
    SET_TOTAL: ( context ) => {
      context.commit( 'SET_TOTAL_PRICE' );
    },
    COUNT_TOTAL_COST: ( {commit} ) => {
      commit( 'TOTAL_COST' );
    }
  }
});

new Vue({
  el: '#app',
  store,
  render: h => h(catalog)
})
