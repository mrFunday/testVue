<template>
  <div class="wrapper">
    <cartHeader />
    <div class="cart-body">
      <div class="cart-body__items">
      <CartItem v-for="(item, index) in products" :key="item.id" :product_data="item" @plusQty="plusQty(index)" @minusQty="minusQty(index)" @removeItems="removeItem(index)" />
        <hr>
      </div>

    <div class="choose-delivery-type">
      <p class="choose-delivery-type__warning">Выберите, пожалуйста, способ доставки вашего заказа.</p>
    </div>
    <div class="cart-body__type-of-delivery">
      <cartTitles title="Выберите способ доставки"/>
      <div class="type-of-delivery__btns">
        <Button @clickEvent="getFromShop" btnText="забрать из магазина" :isActive="activeInShop"/>
        <Button @clickEvent="curierDelivery" btnText="курьерская доставка" :isActive="activeDelivery"/>
        <Button @clickEvent="getFromPost" btnText="доставить в постамат или пвз" :isActive="activePostamat"/>
      </div>
    </div>
      <hr>
    <div class="cart-body__contacts">
      <cartTitles class="contacts" title="Контактные данные"/>
      <div class="contacts__club-programm">
        <p class="club-programm__title">Участники Клубной программы получают дополнительные бонусы.</p>
        <div class="club-programm__btns">
          <div class="btns__registered-user">
            <p>Зарегистрированный покупатель</p>
            <Button class="login" btnText="войти и использовать бонусы" />
          </div>
          <div class="btns__new-user">
            <p>Впервые на O'STIN</p>
            <Button class="login" btnText="зарегистрироваться" />
          </div>
        </div>
      </div>
      <div class="contacts__inputs">
        <div class="inputs__main">
          <textInputs placeholder="Имя " name="name"/>
          <textInputs placeholder="Телефон " name="phone"/>
          <textInputs placeholder="Email " name="e-mail"/>
        </div>
        <p v-if="curier" class="inputs__adress">Адрес доставки:</p>
        <div v-if="curier" class="inputs__secondary">
          <div class="secondary__city-metro">
              <selects v-bind:list="cities"/>
              <selects v-bind:list="metro"/>
          </div>
          <div class="secondary__street-index-building">
            <textInputs style="width: 130px" class="inputs__item" type="text" placeholder="Индекс "/>
            <textInputs style="width: 300px" class="inputs__item street" type="text" placeholder="Улица "/>
            <textInputs style="width: 120px" class="inputs__item" type="text" placeholder="Дом "/>
          </div>
          <div class="secondary__corp-build-flat">
            <textInputs style="width: 26%" class="inputs__item" type="text" placeholder="Корпус " />
            <textInputs style="width: 26%" class="inputs__item" type="text" placeholder="Строение " />
            <textInputs style="width: 26%" class="inputs__item" type="text" placeholder="Квартира " />
          </div>
          <div class="secondary__comment">
            <textInputs style="width: 90%" class="inputs__item comment" type="text" placeholder="Ваши пожелания " />
          </div>
          <div class="secondary__date-and-time">
            <span class="inputs__adress">Желаемая дата и время:</span>
            <textInputs class="inputs__item selects choose-date" type="date" placeholder="Выберите дату" />
            <selects v-bind:list="time"/>
          </div>
        </div>
      </div>
    </div>
    <div class="cart-body__discount-payment">
      <div class="settings-title payment">
        <p>Оплата и скидки</p>
      </div>
      <div class="discount-payment__promo-code">
        <div class="promo-code__code">
          <p>Промокод:</p>
          <textInputs class="promo-code-wrapper" type="text" placeholder="Введите промокод "/>
          <button class="cart-btn promo-btn">изменить</button>
        </div>
        <div class="promo-code__applied">
          <p>Применен к <span>4 товарам</span></p>
          <span class="applied__discount">- 2 396</span>
        </div>
      </div>
      <div class="discount-payment__club-program">
        <p>Клубная программа <br>O'STIN бонус:</p>
        <div class="club-program__checkbox">
          <input id="use-bonuses" type="checkbox">
          <label for="use-bonuses">&nbsp;Использовать бонусы </label>
          <img id="bonus-question" src="/src/assets/img/Symbol 15 – 17.png" alt="faq" title="F.A.Q">
          <p class="available-bonuses">На бонустном счёте <span>400</span> бонусов (1 бонус = 1 рубль)</p>
          <p class="available-bonuses hidden">Для начисления и использования бонусов необходимо <a class="red_price" href="#">авторизоваться</a> или <a class="red_price" href="#">зарегистрироваться</a> на сайте.</p>
        </div>
      </div>
      <div class="discount-payment__payment-method">
        <p>Способ оплаты:</p>
        <div class="payment-method__radios">
          <input id="payment-method__radio1" name="money-radio" checked type="radio">
          <label for="payment-method__radio1">&nbsp;Наличными или картой при получении</label><br>
          <input id="payment-method__radio2" name="money-radio" type="radio">
          <label class="cards-type" for="payment-method__radio2">&nbsp;Картой на сайте</label>
      </div>
      </div>
    </div>
    <div class="cart-body__total">
      <div class="settings-title total">
        <p>Общая стоимость</p>
      </div>
      <totalItem />
      <hr>
      <div class="total__full-summ">
        <div class="full-summ__total">
          <p>Всего к оплате</p>
          <span>{{$store.state.superTotalCost}} руб.</span>
        </div>
        <button class="btn-big red">оформить заказ</button>
        <p class="public-offer">Нажимая кнопку "Формить заказ", вы принимаете условия публичной оферты</p>
      </div>
    </div>
    <div class="cart-body__advantages">
      <div class="advantages__column">
        <p class="column__title bonus-card">Выгодная <br>Клубная программа</p>
        <p class="column__description">Экономия до 30%</p>
        <p class="about-info"><a href="#">Подробнее</a></p>
      </div>
      <div class="advantages__column">
        <p class="column__title delivery">Быстрая доставка</p>
        <p class="column__description">Самовывоз
          из магазинов,
          курьерская служба
          и сеть ПВЗ</p>
        <p class="about-info"><a href="#">Подробнее</a></p>
      </div>
      <div class="advantages__column">
        <p class="column__title comfort-payment">Удобная оплата</p>
        <p class="column__description">Наличными или банковской картой
          в магазине</p>
        <p class="about-info"><a href="#">Подробнее</a></p>
      </div>
      <div class="advantages__column">
        <p class="column__title return">Лёгкий возврат</p>
        <p class="column__description">В любом магазине O’STIN или через Почту России</p>
        <p class="about-info"><a href="#">Подробнее</a></p>
      </div>
    </div>
    </div>
  </div>
</template>

<script>
import './assets/styles/style.scss'
import CartItem from './components/Cart'
import Button from './components/Button'
import cartTitles from './components/cartTitles'
import cartHeader from './components/cartHeader'
import textInputs from './components/textInputs'
import selects from './components/selects'
import totalItem from './components/totalItem'
import { mapGetters } from 'vuex';
export default {
  name: 'CartPage',
  data() {
    return {
      curier: false,
      activeInShop: false,
      activeDelivery: false,
      activePostamat: false,
      cities: this.$store.state.cities,
      metro: this.$store.state.metro,
      time: this.$store.state.time
    }
  },
  computed: {
    ...mapGetters({
     products: 'PRODUCTS'
    })
  },
  methods: {
    curierDelivery() {
      this.curier = true;
      this.activeDelivery = true;
      this.activeInShop = this.activePostamat = false;
    },
    getFromShop() {
      this.curier = false;
      this.activeInShop = true;
      this.activeDelivery = this.activePostamat = false;
    },
    getFromPost() {
      this.curier = false;
      this.activePostamat = true;
      this.activeInShop = this.activeDelivery = false;
    },
    removeItem(index) {
      this.$store.dispatch('REMOVE_ITEMS', index);
    },
    plusQty(index) {
      this.$store.dispatch('PLUS_QTY', index);
    },
    minusQty(index) {
      this.$store.dispatch('MINUS_QTY', index);
    }
  },
  components: {
    CartItem,
    Button,
    cartTitles,
    cartHeader,
    textInputs,
    selects,
    totalItem
  }
}
</script>

<style>

</style>
