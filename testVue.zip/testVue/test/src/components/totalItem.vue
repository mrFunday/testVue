<template>
  <div class="total__content">
    <div class="content__title">
      <p class="title__order-number"><span>1</span> заказ.</p>
      <p class="title__order-adress">Самовывоз сегодня с 15:00 и позже, г. Москва, ул. Борисовские пруды, д. 26</p>
    </div>
    <div class="content__qty">
      <p><span class="amount">{{qty}}</span> товара на сумму</p>
      <p><span>{{$store.state.superPriceNew}} руб.</span></p>
    </div>
    <div class="content__gather">
      <p>Забрать в магазине</p>
      <p><span>{{getInShop}}</span></p>
    </div>
    <div class="content__discount">
      <p><span class="special-conditions">Акция -50% на вторые низы</span></p>
      <p><span class="red_price">- {{$store.state.superAkciyaPrice}} руб.</span></p>
    </div>
    <div class="content__promo">
      <p><span class="special-conditions">Промокод EXTRA</span></p>
      <p><span class="red_price">- {{$store.state.superPricePromo}} руб.</span></p>
    </div>
    <div class="content__bonus">
      <p><span class="special-conditions">Оплата бонусамм</span></p>
      <p><span class="red_price">- {{bonuses}} руб.</span></p>
    </div>
    <div class="content__summ">
      <p><span class="summ">Сумма заказа</span></p>
      <p><span>{{$store.state.superTotalCost}} руб.</span></p>
    </div>
  </div>
</template>

<script>
    export default {
        name: "totalItem",
        props: [],
      data() {
          return {
            qty: '',
            getInShop: 'бесплатно',
            bonuses: '250'
          }
      },
      mounted: function () {
          this.$store.dispatch('COUNT_TOTAL_COST');
      }
    }
</script>

<style scoped>

</style>
