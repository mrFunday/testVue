<template>
    <button @click="clickBtn" class="cart-btn" :disabled='isDisabled' :class="{active:isActive}">{{btnText}}</button>
</template>

<script>
    export default {
        name: "Button",
        props: [
          'btnText',
          'isDisabled',
          'isActive'
        ],
      data() {
        return {

        }
      },
      methods: {
          clickBtn() {
            this.$emit('clickEvent');
          }
      }
    }
</script>

<style scoped>

</style>
