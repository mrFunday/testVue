<template>
  <div v-if="visible" class="items__cart-item">
    <div v-if="readyToDeliver" class="cart-item__unavailable-item">
      <p>Товар недоступен для доставки курьером:</p>
      <a href="#">Забрать в магазине</a>
    </div>
    <div v-if="isInStore" class="cart-item__unavailable-item sold-out">
      <p>Товар распродан:</p>
      <a @click="removeItems" href="#">Удалить</a>
    </div>
    <div class="cart-item__main-part">
      <a href="#"><img :src="product_data.img" alt="cart-item-title"></a>
      <div class="cart-item__info-block">
        <div class="info-block__title">
          <p>{{product_data.title}}</p>
          <a @click="removeItems" href="#"><img src="src/assets/img/remove_cart.png" title="Удалить" alt=""></a>
        </div>
        <div class="info-block__table">
          <table>
            <tbody>
            <tr>
              <td><span class="articul">{{product_data.article}}</span></td>
              <td class="double_info_td">
                <span></span>
                <span class="text_lighter delivery-time">Можем доставить: <span id="delivery-time">12 декабря и позже</span></span>
              </td>
            </tr>
            <tr>
              <td>Размер:</td>
              <td>{{product_data.size}}</td>
            </tr>
            <tr>
              <td>Цвет:</td>
              <td>{{product_data.color}}</td>
            </tr>
            <tr>
              <td>Цена:</td>
              <td><del><span class="del_price text_lighter">{{product_data.priceOld}}</span></del>&nbsp;&nbsp;<span><strong>{{product_data.priceNew}} руб.</strong></span></td>
            </tr>
            <tr>
              <td>Акция:</td>
              <td class="double_info_td">
                <span>{{product_data.akciyaName}}</span>
                <span class="red_price text_lighter">- {{product_data.akciyaPrice}} руб.</span>
              </td>
            </tr>
            <tr>
              <td>Промокод:</td>
              <td class="double_info_td">
                <span class="text_lighter">{{product_data.promocode}}</span>
                <span class="red_price text_lighter">- {{product_data.pricePromo}} руб.</span>
              </td>
            </tr>
            <tr class="items-total">
              <td>
                <div class="total__item-qty">
                  <button v-on:click="minusQty" id="minus">-</button>&nbsp;&nbsp;
                  <span id="qty">{{product_data.qty}}</span>&nbsp;&nbsp;
                  <button v-on:click="plusQty" id="plus">+</button>
                </div>
              </td>
              <td class="double_info_td">
                <span>ИТОГО:</span>
                <div class="total__summ">
                  <span class="text_lighter">{{product_data.totalPrice}} руб.</span>
                </div>
              </td>
            </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
    export default {
        name: "CartItem",
        props: {
            product_data : { type: Object, default: {} }
        },
        data() {
          return {
            delivery: this.product_data.delivery,
            amount: this.product_data.amount,
            visible: Boolean
          }
        },
      mounted: function () {
        this.$store.dispatch('SET_TOTAL');
        this.$store.dispatch('COUNT_TOTAL_COST');
      },
      computed: {
          isInStore() {
            if (this.product_data.amount <= 0) {
              return true;
            } else {
              return false;
            }
          },
        readyToDeliver() {
            if (this.product_data.delivery) {
              return false;
            } else {
              return true;
            }
        }
      },
      methods: {
          plusQty() {
            this.$emit('plusQty');
            this.$store.dispatch('COUNT_TOTAL_COST');
          },
          minusQty() {
            if (this.product_data.qty < 1) {
              return false;
            }  else {
              this.$emit('minusQty');
              this.$store.dispatch('COUNT_TOTAL_COST');
            }
            // if (this.product_data.totalPrice < this.product_data.priceNew) {
            //   this.product_data.qty = 0;
            //   this.product_data.totalPrice = 0;
            // }
          },
        removeItems() {
            this.$emit('removeItems');
            this.$store.dispatch('COUNT_TOTAL_COST');
        }
      }
    }
</script>

<style scoped>

</style>
