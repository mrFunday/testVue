<template>
  <div class="cart-header">
    <p class="cart-header__page-title">Оформление заказа</p>
    <p class="cart-header__back"><a href="#">Вернуться к покупкам</a></p>
  </div>
</template>

<script>
    export default {
        name: "cartHeader"
    }
</script>

<style scoped>

</style>
