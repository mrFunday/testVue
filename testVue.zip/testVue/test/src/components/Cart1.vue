<template>
  <div>
    909
    <hr/>

    <button @click="plusQty">+</button>
    <button @click="minusQty">-</button>
    qty: {{item.qty}}<br/>
    price: {{item.totalPrice}}<br/>

    {{item}}
  </div>
</template>

<script>
    export default {
        name: "CartItem",
        props:['item'],
        mounted: function () {
            var perc = this.item.priceAkciya;
            var total = this.item.priceNew;
            this.item.priceAkciya = (perc * total) / 100;
            this.item.totalPrice = this.item.priceNew - this.item.pricePromo - this.item.priceAkciya;
        },
      //   props: {
      //       product_data : { type: Object, default: {} },
      //       totalSumm : { type: Number, default: 909 }
      //   },
      //   data() {
      //     return {
      //       img: this.product_data.img,
      //       title:this.product_data.title ,
      //       article: this.product_data.article,
      //       size: this.product_data.size,
      //       color: this.product_data.color,
      //       priceOld: this.product_data.priceOld,
      //       priceNew: this.product_data.priceNew,
      //       promocode: this.product_data.promocode,
      //       priceAkciya: '',
      //       pricePromo: this.product_data.pricePromo,
      //       totalPrice: '',
      //       qty: this.product_data.qty,
      //       delivery: this.product_data.delivery,
      //       amount: this.product_data.amount,
      //       visible: Boolean
      //     }
      //   },
      // mounted: function () {
      //     var perc = this.product_data.priceAkciya;
      //     var total = this.priceNew;
      //     this.priceAkciya = (perc * total) / 100;
      //     this.totalPrice = this.priceNew - this.pricePromo - this.priceAkciya;
      // },
      // computed: {
      //     totalSumma() {
      //       console.log(this.totalSumm);
      //       return 10;
      //       // return this.$props.totalSumm = this.totalPrice;
      //     },
      //     isInStore() {
      //       if (this.amount <= 0) {
      //         return true;
      //       } else {
      //         return false;
      //       }
      //     },
      //   readyToDeliver() {
      //       if (this.delivery) {
      //         return false;
      //       } else {
      //         return true;
      //       }
      //   }
      // },
      methods: {
          asd: function(){
            this.$store.dispatch("asd/asd",{
              articl: this.item.article,
              total: this.item.titalPrice
            })
          },
        plusQty() {
          this.item.qty++;
          this.item.totalPrice += (this.item.priceNew - this.item.pricePromo - this.item.priceAkciya);
          this.$emit('total-price', this.item.totalPrice);
          //console.log(this.item.totalSumm)
        },
        minusQty() {
          if (this.qty < 1) {
            return false;
          } else {
            this.qty--;
            this.totalPrice -= (this.priceNew - this.pricePromo - this.priceAkciya);
            //this.$emit('totalPrice');
            // this.asd()
          }
        }
      }
      //   removeItems() {
      //       this.$emit('removeItems');
      //   }
      // }
    }
</script>

<style scoped>

</style>
