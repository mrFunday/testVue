<template>
    <input class="inputs__item" type="text" :name="name" :placeholder="placeholder" >
</template>

<script>
    export default {
      name: "textInputs",
      props: [
        'placeholder',
        'name'
      ]
    }
</script>

<style scoped type >

</style>
