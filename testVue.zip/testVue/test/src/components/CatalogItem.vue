<template>
  <div class="catalog-item_wrap">
    <a href="#"><img :src="catalogproduct_data.img" alt="cart-item-title"></a>
    <p class="catalog-item-title">{{ catalogproduct_data.title }}</p>
    <p class="catalog-item-price">{{ catalogproduct_data.priceNew }} $</p>
    <button class="add-to-cart-btn" href="#" @click="addToCart" v-bind:disabled="isDisabled" v-bind:class="disabledClass">{{ added }}</button>
  </div>
</template>

<script>
  export default {
    name: 'CatalogItem',
    props: {
      catalogproduct_data : { type: Object, default: {} }
    },
    data() {
      return {
        added: 'add to cart',
        isDisabled: false,
        disabledClass: ''
      }
    },
    methods: {
      addToCart(e) {
        this.$emit('addToCart');
        this.isDisabled = !this.isDisabled;
        this.added = 'in cart'
        this.disabledClass = 'disabled'
      }
    }
  }


</script>

<style scoped>
  .catalog-item_wrap {
    text-align: center;
    border: solid 1px #00000052;
  }
  .catalog-item_wrap p {
    padding: 10px 0;
  }
  .catalog-item-title {
    font-size: 2em;
    text-transform: uppercase;
  }
  .catalog-item-price {
    color: #E32526;
    font-size: 25px;
  }
  .add-to-cart-btn {
    cursor: pointer;
    color: #fff;
    text-transform: uppercase;
    background: #44ca86;
    border-radius: 2px;
    border: none;
    padding: 10px;
    position: relative;
    top: 10px;
    transition: ease .2s;
  }
  .add-to-cart-btn:hover {
    color: #fff;
    transition: ease .2s;
    box-shadow: 0px 2px 8px 0px #00000087;
  }
  .add-to-cart-btn.disabled {
    background: #ef6162;
  }
  .add-to-cart-btn.disabled:hover {
    cursor: default;
    color: #fff;
    transition: ease .2s;
    box-shadow: none;
  }
</style>
