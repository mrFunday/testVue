<template>
  <select class="inputs__item selects">
    <option v-for="item in list" value="">{{item}}</option>
  </select>
</template>

<script>
    export default {
        name: "selects",
        props: [
          'list'
        ],
        data() {
          return {

          }
        }
    }
</script>

<style scoped>

</style>
