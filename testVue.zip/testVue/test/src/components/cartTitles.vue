<template>
  <div class="settings-title">
    <p>{{title}}</p>
  </div>
</template>

<script>
    export default {
        name: "cartTitles",
        props: [ 'title' ]
    }
</script>

<style scoped>

</style>
